#include "dialog.c"
gboolean show_info(GtkWidget *widget,gpointer database);
gboolean show_guide(GtkWidget *widget,gpointer database);
gboolean show_dialog(GtkWidget *widget,gpointer database,char *mess);