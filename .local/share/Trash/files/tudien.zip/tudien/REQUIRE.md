```bash
sudo apt-get install -y pkg-config pkgconf libgtk-3-dev glade
```