#include "delete.c"
gboolean delete_word(GtkWidget *widget,gpointer data);
void delete_message(char *w_delete);
gboolean check_delete(GtkWidget *widget,gpointer data);
void window_delete(GtkWidget *widget);