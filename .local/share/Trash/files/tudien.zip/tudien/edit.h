#include "edit.c"
gboolean check_edit(GtkWidget *widget,gpointer data);
void window_edit(GtkWidget *widget);
