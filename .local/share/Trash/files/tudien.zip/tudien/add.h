#include "add.c"

gboolean check_add(GtkWidget *widget,gpointer data);
void window_add(GtkWidget *widget);
