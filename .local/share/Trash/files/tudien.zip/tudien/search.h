#include "search.c"

gboolean check_search(GtkWidget *widget,gpointer data);
void window_Search(GtkWidget *widget);
