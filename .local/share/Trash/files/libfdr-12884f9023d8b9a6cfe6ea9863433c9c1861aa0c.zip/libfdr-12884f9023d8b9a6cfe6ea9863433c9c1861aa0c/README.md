# libfdr
Jim Plank's libfdr. I just want to use CMake instead of classic Make to make integration easier.

Original Jim Plank's codes are not touched, and you are not supposed to do so.

Just use it as is.