#ifndef DEMO_H_
#define DEMO_H_

void demoAllPrintf();

#endif // DEMO_H_