#include "demo.h"

int main() {
  demoAllPrintf();
  return 0;
}