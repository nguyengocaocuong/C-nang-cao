#ifdef ALGORITHM_H_
#define ALGORITHM_H_

void quickSort(int arr[], int lower, int upper);

void display(int arr[], int n);

#endif // ALGORITHM_H_