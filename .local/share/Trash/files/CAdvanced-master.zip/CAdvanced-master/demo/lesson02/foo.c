int foo() {
  return 100;
}