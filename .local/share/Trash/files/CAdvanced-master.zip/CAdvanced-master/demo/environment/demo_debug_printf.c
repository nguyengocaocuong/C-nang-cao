#include "DebugPrintf/debug_printf.h"

int main() {
  printfInfo("Hello world!\n");
  return 0;
}